package com.example.sdk

import com.example.sdk.module.SdkComponent
import org.koin.core.component.inject

class Bar : SdkComponent {
  private val foo: Foo by inject()
  fun foo() = foo.bar() + "foo"
}
