package com.example.sdk.module

import org.koin.core.Koin
import org.koin.core.KoinApplication
import org.koin.core.component.KoinComponent

object SdkContext {
  lateinit var koinApp: KoinApplication
}

interface  SdkComponent : KoinComponent {
  override fun getKoin(): Koin = SdkContext.koinApp.koin
}
