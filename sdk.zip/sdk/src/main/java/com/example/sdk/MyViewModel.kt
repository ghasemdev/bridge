package com.example.sdk

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.example.sdk.module.SdkComponent
import org.koin.core.component.inject

class MyViewModel(
  savedStateHandle: SavedStateHandle
) : ViewModel(), SdkComponent {

  private val foo: Foo by inject()

  init {
    foo.bar()
    savedStateHandle.get<Boolean>("is")
  }

}
