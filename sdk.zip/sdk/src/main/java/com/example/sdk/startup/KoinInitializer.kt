package com.example.sdk.startup

import android.content.Context
import androidx.startup.Initializer
import com.example.sdk.BuildConfig
import com.example.sdk.module.SdkContext
import com.example.sdk.module.sdkModule
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.logger.Level
import org.koin.dsl.koinApplication

internal class KoinInitializer : Initializer<Unit> {

  override fun create(context: Context) {
    SdkContext.koinApp = koinApplication {
      androidContext(context)
      androidLogger(if (BuildConfig.DEBUG) Level.DEBUG else Level.NONE)
      modules(sdkModule)
    }
  }

  override fun dependencies(): List<Class<out Initializer<*>>> = emptyList()

}
