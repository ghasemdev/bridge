package com.example.sdk.module

import org.koin.dsl.module

internal val sdkModule = module {
  includes(someModule)
}
