package com.example.sdk

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.sdk.module.SdkComponent
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.stateViewModel

class SdkActivity : AppCompatActivity(), SdkComponent {

  private val foo: Foo by inject()
  private val vm: MyViewModel by stateViewModel()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    Log.i("SDK", foo.bar())
    Log.i("SDK", Bar().foo())
    vm
  }
}
