package com.example.sdk

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.sdk.module.SdkComponent
import com.example.sdk.module.SdkContext
import com.example.sdk.module.sdkModule
import org.koin.android.ext.android.inject
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.logger.Level
import org.koin.dsl.koinApplication

class SdkActivity : AppCompatActivity(), SdkComponent {

  private val foo: Foo by inject()

  init {
    SdkContext.koinApp = koinApplication {
      androidContext(this@SdkActivity)
      androidLogger(if (BuildConfig.DEBUG) Level.DEBUG else Level.NONE)
      modules(sdkModule)
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    Log.i("SDK", foo.bar())
    Log.i("SDK", Bar().foo())
  }
}
