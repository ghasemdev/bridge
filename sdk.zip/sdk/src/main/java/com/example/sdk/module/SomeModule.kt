package com.example.sdk.module

import com.example.sdk.Foo
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.module

internal val someModule = module {
  singleOf(::Foo)
}
