package com.example.sdk

class Foo {
  fun bar() = "bar"
}
