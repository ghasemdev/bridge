package com.example.sdk.module

import com.example.sdk.Foo
import com.example.sdk.MyViewModel
import org.koin.androidx.viewmodel.dsl.viewModelOf
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.module

internal val someModule = module {
  singleOf(::Foo)
  viewModelOf(::MyViewModel)
}
