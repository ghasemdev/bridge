package ir.partsoftware.digitalsignsdk.data.di

import android.annotation.SuppressLint
import android.content.Context
import com.chuckerteam.chucker.api.ChuckerCollector
import com.chuckerteam.chucker.api.ChuckerInterceptor
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import ir.partsoftware.digitalsignsdk.BuildConfig
import ir.partsoftware.digitalsignsdk.data.api.*
import ir.partsoftware.digitalsignsdk.data.utils.GatewayInterceptor
import ir.partsoftware.digitalsignsdk.data.utils.NetworkConnectionInterceptor
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.Json
import okhttp3.CertificatePinner
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Converter
import retrofit2.Retrofit
import java.security.KeyStore
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton
import javax.net.ssl.*

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @DigitalSignSDKLibrary
    fun provideOkHttpClient(
        @ApplicationContext context: Context,
        @DigitalSignSDKLibrary sslSocketFactory: SSLSocketFactory,
        @DigitalSignSDKLibrary trustManager: X509TrustManager,
        gatewayInterceptor: GatewayInterceptor,
//        @DigitalSignSDKLibrary certificatePinner: CertificatePinner,
    ): OkHttpClient {
        val chucker = ChuckerInterceptor.Builder(context)
            .collector(ChuckerCollector(context))
            .maxContentLength(250000L)
            .redactHeaders(emptySet())
            .alwaysReadResponseBody(false)
            .build()

        val httpLogger = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BODY
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }

        return OkHttpClient.Builder()
            .connectTimeout(120, TimeUnit.SECONDS)
            .callTimeout(120, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(120, TimeUnit.SECONDS)
            .addInterceptor(NetworkConnectionInterceptor(context = context))
            .addInterceptor(gatewayInterceptor)
            .addInterceptor(chucker)
            .addInterceptor(httpLogger)
            .sslSocketFactory(sslSocketFactory, trustManager)
//            .certificatePinner(certificatePinner)
            .hostnameVerifier { _, _ -> true }
            .build()
    }

    @OptIn(ExperimentalSerializationApi::class)
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        explicitNulls = false
    }

    @Provides
    @DigitalSignSDKLibrary
    @ExperimentalSerializationApi
    fun provideSerializableFactory() = json.asConverterFactory("application/json".toMediaType())

    @Provides
    @DigitalSignSDKLibrary
    fun provideRetrofit(
        @DigitalSignSDKLibrary client: OkHttpClient,
        @DigitalSignSDKLibrary converterFactory: Converter.Factory,
    ): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .client(client)
            .addConverterFactory(converterFactory)
            .build()
    }

    @Provides
    @Named("Barjavand")
    fun provideBarjavandRetrofit(
        @DigitalSignSDKLibrary client: OkHttpClient,
        @DigitalSignSDKLibrary converterFactory: Converter.Factory,
    ): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.BARJAVAND_URL)
            .client(client)
            .addConverterFactory(converterFactory)
            .build()
    }

    @Provides
    @DigitalSignSDKLibrary
    fun provideSslFactory(): SSLSocketFactory {
        // Create a trust manager that does not validate certificate chains
        val trustAllCerts = arrayOf<TrustManager>(
            @SuppressLint("CustomX509TrustManager")
            object : X509TrustManager {
                @SuppressLint("TrustAllX509TrustManager")
                @Throws(CertificateException::class)
                override fun checkClientTrusted(
                    chain: Array<X509Certificate?>?,
                    authType: String?
                ) {
                }

                @SuppressLint("TrustAllX509TrustManager")
                @Throws(CertificateException::class)
                override fun checkServerTrusted(
                    chain: Array<X509Certificate?>?,
                    authType: String?
                ) {
                }

                override fun getAcceptedIssuers(): Array<X509Certificate?> {
                    return arrayOf()
                }
            }
        )

        // Install the all-trusting trust manager
        val sslContext = SSLContext.getInstance("SSL")
        sslContext.init(null, trustAllCerts, SecureRandom())
        // Create a ssl socket factory with our all-trusting manager
        return sslContext.socketFactory
    }

    @Provides
    @DigitalSignSDKLibrary
    fun provideTrustManager(): X509TrustManager {
        val trustManagerFactory: TrustManagerFactory =
            TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        trustManagerFactory.init(null as KeyStore?)
        val trustManagers: Array<TrustManager> =
            trustManagerFactory.trustManagers
        check(!(trustManagers.size != 1 || trustManagers[0] !is X509TrustManager)) {
            "Unexpected default trust managers:" + trustManagers.contentToString()
        }
        return trustManagers[0] as X509TrustManager
    }

    @Provides
    @DigitalSignSDKLibrary
    fun provideCertPinner(): CertificatePinner {
        return CertificatePinner.Builder()
            .add(
                "digitalsignature-v1-dev.apipart.ir",
                "sha256/geMRnWzR7Yn04uR/sES9Ah7m6Q1F4sn5y376Aohcvjc=",
                "sha256/2YdMferqpRoHvjtT2LkdoFKCfbcy8q1kE/2O5L/aJrs=",
            )
            .build()
    }

    @Provides
    @DigitalSignSDKLibrary
    fun provideStepOrderApiService(@DigitalSignSDKLibrary retrofit: Retrofit): StepOrderApiService {
        return retrofit.create(StepOrderApiService::class.java)
    }

    @Provides
    @DigitalSignSDKLibrary
    fun provideCertificateApiService(@DigitalSignSDKLibrary retrofit: Retrofit): CertificateApiService {
        return retrofit.create(CertificateApiService::class.java)
    }

    @Provides
    @DigitalSignSDKLibrary
    fun provideAuthenticationApiService(@DigitalSignSDKLibrary retrofit: Retrofit): AuthenticationApiService {
        return retrofit.create(AuthenticationApiService::class.java)
    }

    @Provides
    @DigitalSignSDKLibrary
    fun providePaymentApiService(@DigitalSignSDKLibrary retrofit: Retrofit): PaymentApiService {
        return retrofit.create(PaymentApiService::class.java)
    }

    @Provides
    @DigitalSignSDKLibrary
    fun provideOtpApiService(@DigitalSignSDKLibrary retrofit: Retrofit): OtpApiService {
        return retrofit.create(OtpApiService::class.java)
    }

    @Provides
    @DigitalSignSDKLibrary
    fun provideInitConfigApiService(@Named("Barjavand") retrofit: Retrofit): InitConfigApiService {
        return retrofit.create(InitConfigApiService::class.java)
    }
}
