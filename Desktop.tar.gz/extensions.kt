package ir.partsoftware.digitalsignsdk.data.utils

import com.nimbusds.jose.JWSAlgorithm
import com.nimbusds.jose.JWSHeader
import retrofit2.HttpException
import retrofit2.Response

@Throws(ServerException::class)
fun <T> Response<T>.bodyOrThrow(): T {
    if (!isSuccessful) throw HttpException(this)
    return body()!!
}

/**
 * Creates a new JWS header builder.
 *
 * @param alg The JWS algorithm `alg` parameter. Must not be "none" or `null`.
 * @param builder JWSHeader builder block.
 */
inline fun JWSHeader(
    alg: JWSAlgorithm,
    builder: JWSHeader.Builder.() -> JWSHeader.Builder
): JWSHeader = builder(JWSHeader.Builder(alg)).build()
