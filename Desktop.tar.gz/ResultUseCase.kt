package ir.partsoftware.digitalsignsdk.domain.usecase.base

import ir.partsoftware.digitalsignsdk.data.utils.VpnException
import ir.partsoftware.digitalsignsdk.domain.utils.Resource
import ir.partsoftware.digitalsignsdk.domain.utils.readServerError
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.InterruptedIOException
import java.net.SocketTimeoutException

/**
 * Executes business logic synchronously or asynchronously using Coroutines.
 *
 * The [execute] method of [SuspendUseCase] is a suspend function as opposed to the
 * [SuspendUseCase.execute] method of [UseCase].
 */
abstract class ResultUseCase<out R>(private val dispatcher: CoroutineDispatcher) {

    /** Executes the use case asynchronously and returns a [Resource].
     *
     * @return a [Resource].
     *
     * @param params the input parameters to run the use case with
     */
    suspend operator fun invoke(): R {
        return try {
            // Moving all use case's executions to the injected dispatcher
            // In production code, this is usually the Default dispatcher (background thread)
            // In tests, this becomes a TestCoroutineDispatcher
            withContext(dispatcher) {
                execute()
            }
        } catch (e: CancellationException) {
            throw Exception()
        } catch (e: HttpException) {
            val parsedError = if (e.code() == 403 &&
                e.response()?.headers()?.get("X-Powered-By")?.contains("partFramework") == false
            ) {
                VpnException()
            } else {
                try {
                    readServerError(e)
                } catch (e: Exception) {
                    Exception(e)
                }
            }
            throw parsedError
        } catch (e: InterruptedIOException) {
            throw SocketTimeoutException(e.message)
        } catch (e: Exception) {
            throw e
        }
    }

    /**
     * Override this to set the code to be executed.
     */
    protected abstract suspend fun execute(): R
}
