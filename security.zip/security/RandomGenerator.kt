package com.example.coffein.security

import android.os.Build
import java.security.SecureRandom

/**
 * It is used to generate random content such as a token, one-time password or a key.
 * @since 2.0.0
 * @param generatorContent The generator content is a string can be used to create a random token.
 */
@JvmInline
value class RandomGenerator(private val generatorContent: String) {

  init {
    require(generatorContent.isNotEmpty()) { "Generator content can't be empty!" }
  }

  /**
   * Generates a random token with specified [size].
   *
   * Example:
   * ```kotlin
   * val otpGenerator = RandomGenerator("0123456789")
   * otpGenerator.generateToken(4) // 3264
   * ```
   * @since 2.0.0
   * @param size length of the random token. Default length is **8**.
   * @return a string containing random values.
   */
  @JvmOverloads
  fun generateToken(size: Int = 8): String {
    return buildString {
      repeat(size) {
        append(generatorContent[random.nextInt(generatorContent.length)])
      }
    }
  }

  /**
   * [RandomGenerator] builder used for configure a generator content.
   * @since 2.0.0
   */
  class Builder(initializer: Builder.() -> Unit = {}) {

    private val generatorContent: StringBuilder = StringBuilder()

    init {
      initializer()
    }

    /**
     * Append *English* numbers to generator content (0-9).
     * @since 2.0.0
     */
    fun appendNumbers() = apply { generatorContent.append(NUMBERS) }

    /**
     * Append symbols to generator content (!@#$%^&*_=+-/.?<>).
     * @since 2.0.0
     */
    fun appendSymbols() = apply { generatorContent.append(SYMBOLS) }

    /**
     * Append capital *English* letter to generator content (A-Z).
     * @since 2.0.0
     */
    fun appendCapitalLetters() = apply { generatorContent.append(CAPITAL_CHARS) }

    /**
     * Append small *English* letter to generator content (a-z).
     * @since 2.0.0
     */
    fun appendSmallLetters() = apply { generatorContent.append(SMALL_CHARS) }

    /**
     * Append specific letters to generator content.
     * @since 2.0.0
     * @param letters your special letter.
     */
    fun appendSpecificLetters(letters: String) = apply { generatorContent.append(letters) }

    /**
     * Create a new instance of [RandomGenerator].
     * @since 2.0.0
     */
    fun build(): RandomGenerator {
      require(generatorContent.isNotEmpty()) { "Generator content can't be empty!" }
      return RandomGenerator(generatorContent.toString())
    }
  }

  companion object {
    private const val CAPITAL_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    private const val SMALL_CHARS = "abcdefghijklmnopqrstuvwxyz"
    private const val NUMBERS = "0123456789"
    private const val SYMBOLS = "!@#$%^&*_=+-/.?<>"

    private val random by lazy {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        SecureRandom.getInstanceStrong()
      } else {
        SecureRandom()
      }
    }

    /**
     * Generates a random key with specified [size].
     *
     * Example:
     * ```kotlin
     * RandomGenerator.generateKey()
     * ```
     * @since 2.0.0
     * @param size size of the random key. Default size is **32**.
     * @return a byte array containing random values.
     */
    @JvmStatic
    @JvmOverloads
    fun generateKey(size: Int = 32): ByteArray =
      ByteArray(size).apply { random.nextBytes(this) }
  }
}

/**
 * Create a new instance of [RandomGenerator].
 *
 * Example:
 * ```kotlin
 * val generator = randomGenerator {
 *   appendSymbols()
 *   appendNumbers()
 * }
 * val generator.generateToken() // 15#56!$1
 * ```
 * @since 2.0.0
 */
@JvmSynthetic
fun randomGenerator(initializer: RandomGenerator.Builder.() -> Unit): RandomGenerator =
  RandomGenerator.Builder(initializer).build()
