package com.example.coffein.security

import android.content.Context
import android.os.Build
import java.io.InputStream
import java.io.OutputStream
import kotlin.coroutines.CoroutineContext

/**
 * # CryptoManager
 *
 * Managed Crypto implementation at different API levels.
 * @since 2.0.0
 * @see Cryptographic
 */
object CryptoManager : Cryptographic() {

  private var cryptographic: Cryptographic? = null

  /** Initialize crypto manager. */
  fun init(context: Context) {
    cryptographic = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      CryptographicImplForAboveMarshmallow()
    } else {
      CryptographicImplForBelowMarshmallow(context)
    }
  }

  override fun encrypt(content: String): SecureData {
    if (cryptographic == null) {
      throw CryptographicException(
        message = "Cryptographic doesn't initialize, Please before encryption call `init(context)`."
      )
    }
    return cryptographic!!.encrypt(content)
  }

  override fun decrypt(secureData: SecureData): String {
    if (cryptographic == null) {
      throw CryptographicException(
        message = "Cryptographic doesn't initialize, Please before decryption call `init(context)`."
      )
    }
    return cryptographic!!.decrypt(secureData)
  }

  override suspend fun encrypt(
    bytes: ByteArray,
    outputStream: OutputStream,
    context: CoroutineContext
  ): ByteArray {
    if (cryptographic == null) {
      throw CryptographicException(
        message = "Cryptographic doesn't initialize, Please before encryption call `init(context)`."
      )
    }
    return cryptographic!!.encrypt(bytes, outputStream, context)
  }

  override suspend fun decrypt(
    inputStream: InputStream,
    context: CoroutineContext
  ): ByteArray {
    if (cryptographic == null) {
      throw CryptographicException(
        message = "Cryptographic doesn't initialize, Please before decryption call `init(context)`."
      )
    }
    return cryptographic!!.decrypt(inputStream, context)
  }

  /** Perform any final cleanup before an [Cryptographic] is destroyed. */
  fun onDestroy() {
    cryptographic = null
  }
}
