package com.example.coffein.security

import android.os.Build
import java.io.InputStream
import java.io.OutputStream
import kotlin.coroutines.CoroutineContext

object CryptoManager : Cryptographic() {

    private var cryptographic: Cryptographic = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        CryptographicImplForAboveMarshmallow()
    } else {
        CryptographicImplForBelowMarshmallow()
    }

    override fun encrypt(plain: String): SecureData = cryptographic.encrypt(plain)

    override fun decrypt(encryptedPlain: SecureData): String = cryptographic.decrypt(encryptedPlain)

    override suspend fun encrypt(
        bytes: ByteArray,
        outputStream: OutputStream,
        context: CoroutineContext
    ): ByteArray = cryptographic.encrypt(bytes, outputStream, context)

    override suspend fun decrypt(
        inputStream: InputStream,
        context: CoroutineContext
    ): ByteArray = cryptographic.decrypt(inputStream, context)

}
