package com.example.coffein.security

import android.content.SharedPreferences
import androidx.core.content.edit
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * serializes a data type into string performs encryption
 * stores encrypted data in SharedPreferences.
 *
 * Example:
 * ```kotlin
 * sharedPref.secureEdit(value) { encryptedValue ->
 *   putString(KEY, encryptedValue)
 * }
 * ```
 * @since 2.0.0
 */
inline fun <reified T> SharedPreferences.secureEdit(
  value: T,
  action: SharedPreferences.Editor.(value: String) -> Unit
) {
  val encryptedValue = CryptoManager.encrypt(Json.encodeToString(value))
  val editor = edit()
  action(editor, encryptedValue.toString())
  editor.apply()
}

/**
 * Set a secure data type value in the preference.
 *
 * Example:
 * ```kotlin
 * sharedPref.putSecure(KEY, value))
 * ```
 * @since 2.0.0
 */
inline fun <reified T> SharedPreferences.putSecure(
  key: String,
  value: T,
  saltKey: String? = null
) {
  val encryptedValue = CryptoManager.encrypt(Json.encodeToString(value))
  edit {
    putString(Hashing.sha256(key, saltKey), encryptedValue.toString())
  }
}

/**
 * Retrieve a secure data type value from the preferences.
 *
 * Example:
 * ```kotlin
 * sharedPref.getSecure(KEY, defValue)
 * ```
 * @since 2.0.0
 */
inline fun <reified T> SharedPreferences.getSecure(
  key: String,
  defValue: T,
  saltKey: String? = null
): T {
  val data = getString(Hashing.sha256(key, saltKey), null)
  return if (data != null) {
    val decryptedValue = CryptoManager.decrypt(SecureData.toSecureData(data))
    jsonCrypto.decodeFromString(decryptedValue)
  } else {
    defValue
  }
}

/**
 * Retrieve a secure data type value from the preferences.
 * If value doesn't exist then raise an exception.
 *
 * Example:
 * ```kotlin
 * sharedPref.getSecure(KEY)
 * ```
 * @since 2.0.0
 */
inline fun <reified T> SharedPreferences.getSecure(
  key: String,
  saltKey: String? = null
): T {
  val data = getString(Hashing.sha256(key, saltKey), null)
  if (data != null) {
    val decryptedValue = CryptoManager.decrypt(SecureData.toSecureData(data))
    return jsonCrypto.decodeFromString(decryptedValue)
  }
  throw IllegalArgumentException("Secure data not found: $key")
}

/**
 * Retrieve a secure data type value from the preferences.
 * If value doesn't exist, then returns null.
 *
 * Example:
 * ```kotlin
 * sharedPref.getSecureOrNull(KEY)
 * ```
 * @since 2.0.0
 */
inline fun <reified T> SharedPreferences.getSecureOrNull(
  key: String,
  saltKey: String? = null
): T? {
  val data = getString(Hashing.sha256(key, saltKey), null)
  return if (data != null) {
    val decryptedValue = CryptoManager.decrypt(SecureData.toSecureData(data))
    jsonCrypto.decodeFromString(decryptedValue)
  } else {
    null
  }
}
