package com.example.coffein.security

import android.content.SharedPreferences
import androidx.core.content.edit
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * serializes data type into string performs encryption
 * stores encrypted data in SharedPreferences
 *
 * Example:
 * ```kotlin
 * sharedPref.secureEdit(value) { encryptedValue ->
 *   putString(KEY, encryptedValue)
 * }
 * ```
 * @since 2.0.0
 */
inline fun <reified T> SharedPreferences.secureEdit(
    value: T,
    action: SharedPreferences.Editor.(value: String) -> Unit
) {
    val encryptedValue = CryptoManager.encrypt(Json.encodeToString(value))
    val editor = edit()
    action(editor, encryptedValue.toString())
    editor.apply()
}

inline fun <reified T> SharedPreferences.putSecure(key: String, value: T) {
    val encryptedValue = CryptoManager.encrypt(Json.encodeToString(value))
    edit {
        putString(key, encryptedValue.toString())
    }
}

inline fun <reified T> SharedPreferences.getSecure(key: String, defValue: T): T {
    val data = getString(key, null)
    return if (data != null) {
        val decryptedValue = CryptoManager.decrypt(SecureData.decode(data))
        jsonCrypto.decodeFromString(decryptedValue)
    } else {
        defValue
    }
}

inline fun <reified T> SharedPreferences.getSecure(key: String): T? {
    val data = getString(key, null)
    return if (data != null) {
        val decryptedValue = CryptoManager.decrypt(SecureData.decode(data))
        jsonCrypto.decodeFromString(decryptedValue)
    } else {
        null
    }
}
