package com.example.coffein.security

import java.security.MessageDigest

object Hashing {

  private val sha256: MessageDigest by lazy { MessageDigest.getInstance(SHA256) }
  private val sha384: MessageDigest by lazy { MessageDigest.getInstance(SHA384) }
  private val sha512: MessageDigest by lazy { MessageDigest.getInstance(SHA512) }

  fun sha256(plain: String, salt: String? = null): String = sha256.hash(salt, plain)
  fun sha384(plain: String, salt: String? = null): String = sha384.hash(salt, plain)
  fun sha512(plain: String, salt: String? = null): String = sha512.hash(salt, plain)

  private fun MessageDigest.hash(salt: String?, plain: String): String {
    if (salt != null) update(salt.encodeToByteArray())
    return digest(plain.encodeToByteArray())
      .fold("") { str, it -> str + "%02X".format(it) }
  }

  private const val SHA256 = "SHA-256"
  private const val SHA384 = "SHA-384"
  private const val SHA512 = "SHA-512"
}
