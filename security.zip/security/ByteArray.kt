package com.parsuomash.tick.core.ui.security

import java.io.ByteArrayOutputStream
import java.io.InputStream

/**
 * Trim the zero sells in [ByteArray].
 * @since 2.0.0
 */
fun ByteArray.trim(): ByteArray {
  var i = size - 1
  while (i >= 0 && this[i] == 0.toByte()) {
    --i
  }
  return copyOf(i + 1)
}

/**
 * Concatenate the [ByteArray]s and return a new instance.
 * @since 2.0.0
 */
fun ByteArray.concat(other: ByteArray): ByteArray {
  val toReturn = ByteArray(size + other.size)
  for (i in indices) {
    toReturn[i] = this[i]
  }
  for (i in other.indices) {
    toReturn[i + size] = other[i]
  }
  return toReturn
}

/**
 * Convert [InputStream] to [ByteArray].
 * @since 2.0.0
 */
fun InputStream.toByteArray(): ByteArray = buffered().use { bis ->
  ByteArrayOutputStream().use { os ->
    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
    var length = bis.read(buffer)

    while (length != -1) {
      os.write(buffer, 0, length)
      length = bis.read(buffer)
    }
    os.toByteArray()
  }
}
