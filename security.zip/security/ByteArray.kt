package com.example.coffein.security

fun ByteArray.trim(): ByteArray {
    var i = size - 1
    while (i >= 0 && this[i] == 0.toByte()) {
        --i
    }
    return copyOf(i + 1)
}
