@file:Suppress("DEPRECATION")

package com.example.coffein.security

import android.content.Context
import android.security.KeyPairGeneratorSpec
import com.parsuomash.tick.core.ui.security.concat
import com.parsuomash.tick.core.ui.security.toByteArray
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.util.*
import javax.crypto.Cipher
import javax.security.auth.x500.X500Principal
import kotlin.coroutines.CoroutineContext

internal class CryptographicImplForBelowMarshmallow(
  private val context: Context
) : Cryptographic() {

  private val encryptionCipher by lazy {
    Cipher.getInstance(TRANSFORMATION).apply {
      init(Cipher.ENCRYPT_MODE, getAsymmetricKeyPair().public)
    }
  }

  private val decryptionCipher by lazy {
    Cipher.getInstance(TRANSFORMATION).apply {
      init(Cipher.DECRYPT_MODE, getAsymmetricKeyPair().private)
    }
  }

  private fun getAsymmetricKeyPair(): KeyPair {
    val privateKey = keyStore.getKey(KEY_ALIAS, null) as PrivateKey?
    val publicKey = keyStore.getCertificate(KEY_ALIAS)?.publicKey

    return if (privateKey != null && publicKey != null) {
      KeyPair(publicKey, privateKey)
    } else {
      generateKey()
    }
  }

  private fun generateKey(): KeyPair {
    // We create the start and expiry date for the key
    val startDate = Calendar.getInstance()
    val endDate = Calendar.getInstance().apply {
      add(Calendar.YEAR, CERTIFICATE_TIME)
    }

    // We are creating an RSA key pair and store it in the Android Keystore
    val keyPairGenerator = KeyPairGenerator.getInstance(ALGORITHM, ANDROID_KEYSTORE)

    val subject = X500Principal(
      "CN=francescojo.github.com, OU=Android dev, O=Francesco Jo, L=Chiyoda, ST=Tokyo, C=JP"
    )

    // We are creating a key pair with sign and verify purposes
    val parameterSpec = KeyPairGeneratorSpec.Builder(context)
      .setKeySize(KEY_SIZE)
      .setAlias(KEY_ALIAS)
      .setSubject(subject)
      .setSerialNumber(BigInteger.ONE)
      .setStartDate(startDate.time)
      .setEndDate(endDate.time)
      .build()

    // Initialization of key generator with the parameters we have specified above
    keyPairGenerator.initialize(parameterSpec)

    // Generates the key pair
    return keyPairGenerator.genKeyPair()
  }

  override fun encrypt(content: String): SecureData {
    val bytes = content.encodeToByteArray()
    val encryptedBytes = decodeWithBuffer(encryptionCipher, bytes, ENCRYPTION_BUFFER_SIZE)
    return SecureData(plain = encryptedBytes.encodeBase64ToString())
  }

  override fun decrypt(secureData: SecureData): String {
    val bytes = secureData.plain.decodeBase64ToBytes()
    val decryptedBytes = decodeWithBuffer(decryptionCipher, bytes, DECRYPTION_BUFFER_SIZE)
    return decryptedBytes.decodeToString()
  }

  override suspend fun encrypt(
    bytes: ByteArray,
    outputStream: OutputStream,
    context: CoroutineContext
  ): ByteArray = withContext(context) {
    val encryptedBytes = decodeWithBuffer(encryptionCipher, bytes, ENCRYPTION_BUFFER_SIZE)
    outputStream.buffered().use {
      it.write(encryptedBytes)
    }
    encryptedBytes
  }

  override suspend fun decrypt(
    inputStream: InputStream,
    context: CoroutineContext
  ): ByteArray = withContext(context) {
    val bytes = inputStream.toByteArray()
    val decryptedBytes = decodeWithBuffer(decryptionCipher, bytes, DECRYPTION_BUFFER_SIZE)
    decryptedBytes
  }

  private fun decodeWithBuffer(cipher: Cipher, bytes: ByteArray, bufferLength: Int): ByteArray {
    // string initializes 2 buffers.
    // scrambled will hold intermediate results
    var scrambled: ByteArray

    // toReturn will hold the total result
    var toReturn = ByteArray(0)

    // holds the bytes that have to be modified in one step
    var buffer = ByteArray(if (bytes.size > bufferLength) bufferLength else bytes.size)
    for (i in bytes.indices) {
      if (i > 0 && i % bufferLength == 0) {
        //execute the operation
        scrambled = cipher.doFinal(buffer)
        // add the result to our total result.
        toReturn = toReturn.concat(scrambled)
        // here we calculate the bufferLength of the next buffer required
        var newLength = bufferLength

        // if newLength are longer than the remaining bytes in the bytes array, we shorten it.
        if (i + bufferLength > bytes.size) {
          newLength = bytes.size - i
        }
        // clean the buffer array
        buffer = ByteArray(newLength)
      }
      // copy byte into our buffer.
      buffer[i % bufferLength] = bytes[i]
    }

    // this step is needed if we had a trailing buffer.
    // should only happen when encrypting.
    // example: we encrypt 110 bytes.
    // 100 bytes per run means we "forgot" the last 10 bytes.
    // they are in the buffer array
    scrambled = cipher.doFinal(buffer)

    // final step before we can return the modified data.
    toReturn = toReturn.concat(scrambled)
    return toReturn
  }

  companion object {
    private const val ALGORITHM = "RSA"
    private const val BLOCK_MODE = "ECB"
    private const val PADDING = "PKCS1Padding"
    private const val TRANSFORMATION = "$ALGORITHM/$BLOCK_MODE/$PADDING"

    private const val KEY_SIZE = 4096
    private const val DECRYPTION_BUFFER_SIZE = 512
    private const val ENCRYPTION_BUFFER_SIZE = DECRYPTION_BUFFER_SIZE - 11
    private const val CERTIFICATE_TIME = 25 // year
  }
}
