package com.example.coffein.security

import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import javax.crypto.Cipher
import kotlin.coroutines.CoroutineContext

internal class CryptographicImplForBelowMarshmallow : Cryptographic() {

    private val encryptionCipher by lazy {
        Cipher.getInstance(TRANSFORMATION).apply {
            init(Cipher.ENCRYPT_MODE, getAsymmetricKeyPair().public)
        }
    }

    private val decryptionCipher by lazy {
        Cipher.getInstance(TRANSFORMATION).apply {
            init(Cipher.DECRYPT_MODE, getAsymmetricKeyPair().private)
        }
    }

    private fun getAsymmetricKeyPair(): KeyPair {
        val privateKey = keyStore.getKey(KEY_ALIAS, null) as PrivateKey?
        val publicKey = keyStore.getCertificate(KEY_ALIAS)?.publicKey

        return if (privateKey != null && publicKey != null) {
            KeyPair(publicKey, privateKey)
        } else {
            createAsymmetricKeyPair()
        }
    }

    private fun createAsymmetricKeyPair(): KeyPair {
        val generator = KeyPairGenerator.getInstance("RSA")
        generator.initialize(2048)
        return generator.generateKeyPair()
    }

    override fun encrypt(plain: String): SecureData {
        val encryptedBytes = encryptionCipher.doFinal(plain.encodeToByteArray())
        return SecureData(content = encryptedBytes.encodeBase64())
    }

    override fun decrypt(encryptedPlain: SecureData): String {
        val decryptedBytes = decryptionCipher.doFinal(encryptedPlain.content.decodeBase64())
        return decryptedBytes.decodeToString()
    }

    override suspend fun encrypt(
        bytes: ByteArray,
        outputStream: OutputStream,
        context: CoroutineContext
    ): ByteArray = withContext(context) {
        // Encrypt content
        val encryptedBytes = encryptionCipher.doFinal(bytes)

        // Write IV and encrypted bytes to OutputStream
        outputStream.buffered().use { bos ->
            bos.write(encryptedBytes)
        }
        encryptedBytes
    }

    override suspend fun decrypt(
        inputStream: InputStream,
        context: CoroutineContext
    ): ByteArray = withContext(context) {
        // Create a buffer for performance optimization
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)

        inputStream.buffered().use { bis ->
            var length = bis.read(buffer)

            ByteArrayOutputStream().use { decryptedBytes ->
                while (length >= 0) {
                    val trimBuffer = if (length != DEFAULT_BUFFER_SIZE) buffer.trim() else buffer
                    val bytes = decryptionCipher.update(trimBuffer, 0, length)
                    if (bytes != null) {
                        decryptedBytes.write(bytes)
                    }
                    length = bis.read(buffer)
                }
                decryptedBytes.write(decryptionCipher.doFinal())

                decryptedBytes.toByteArray()
            }
        }
    }

    companion object {
        private const val ALGORITHM = "RSA"
        private const val BLOCK_MODE = "ECB"
        private const val PADDING = "PKCS1Padding"
        private const val TRANSFORMATION = "$ALGORITHM/$BLOCK_MODE/$PADDING"
    }
}
