package com.example.coffein.security

/**
 * Holder for secure data includes IV and plain.
 * @since 2.0.0
 */
class SecureData(
  val plain: String,
  val iv: String? = null
) {
  override fun equals(other: Any?): Boolean {
    if (this === other) return true
    if (javaClass != other?.javaClass) return false

    other as SecureData

    if (plain != other.plain) return false
    if (iv != other.iv) return false

    return true
  }

  override fun hashCode(): Int {
    var result = plain.hashCode()
    result = 31 * result + iv.hashCode()
    return result
  }

  override fun toString(): String = if (iv == null) plain else "$iv $plain"

  companion object {
    fun toSecureData(value: String): SecureData = if (value.contains(" ")) {
      val (iv, content) = value.split(" ")
      SecureData(iv = iv, plain = content)
    } else {
      SecureData(plain = value)
    }
  }
}
