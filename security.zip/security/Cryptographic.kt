package com.example.coffein.security

import java.io.InputStream
import java.io.OutputStream
import java.security.KeyStore
import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.Dispatchers

/**
 * # Cryptographic
 *
 * Cryptographic class provides a secure way to encrypt and decrypt data directory
 * or with file storing.
 *
 * @since 2.0.0
 * @see CryptographicImplForAboveMarshmallow
 * @see CryptographicImplForBelowMarshmallow
 */
abstract class Cryptographic {

  protected val keyStore: KeyStore by lazy {
    KeyStore.getInstance(ANDROID_KEYSTORE).apply {
      load(null)
    }
  }

  /** remove existing key store. */
  fun removeKeyStore() {
    if (isKeyExists()) {
      keyStore.deleteEntry(KEY_ALIAS)
    }
  }

  private fun isKeyExists(): Boolean {
    val aliases = keyStore.aliases()
    while (aliases.hasMoreElements()) {
      return (KEY_ALIAS == aliases.nextElement())
    }
    return false
  }

  /** Encrypt string content directly. */
  abstract fun encrypt(content: String): SecureData

  /** Decrypt secure data. */
  abstract fun decrypt(secureData: SecureData): String

  /**
   * Encrypt bytes to an output stream.
   *
   * **Used for large files.**
   */
  abstract suspend fun encrypt(
    bytes: ByteArray,
    outputStream: OutputStream,
    context: CoroutineContext = Dispatchers.IO
  ): ByteArray

  /**
   * Decrypt inputStream as bytes.
   *
   * **Used for large files.**
   */
  abstract suspend fun decrypt(
    inputStream: InputStream,
    context: CoroutineContext = Dispatchers.IO
  ): ByteArray

  companion object {
    const val ANDROID_KEYSTORE = "AndroidKeyStore"
    const val KEY_ALIAS = "LatOPetHtheaCiar"
  }
}
