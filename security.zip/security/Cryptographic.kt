package com.example.coffein.security

import kotlinx.coroutines.Dispatchers
import java.io.InputStream
import java.io.OutputStream
import java.security.KeyStore
import kotlin.coroutines.CoroutineContext

 abstract class Cryptographic {

    protected val keyStore: KeyStore by lazy {
        KeyStore.getInstance(ANDROID_KEYSTORE).apply {
            load(null)
        }
    }

    fun removeKeyStore() {
        if (isKeyExists()) {
            keyStore.deleteEntry(KEY_ALIAS)
        }
    }

    private fun isKeyExists(): Boolean {
        val aliases = keyStore.aliases()
        while (aliases.hasMoreElements()) {
            return (KEY_ALIAS == aliases.nextElement())
        }
        return false
    }

    abstract fun encrypt(plain: String): SecureData
    abstract fun decrypt(encryptedPlain: SecureData): String

    abstract suspend fun encrypt(
        bytes: ByteArray,
        outputStream: OutputStream,
        context: CoroutineContext = Dispatchers.IO
    ): ByteArray

    abstract suspend fun decrypt(
        inputStream: InputStream,
        context: CoroutineContext = Dispatchers.IO
    ): ByteArray

    companion object {
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val KEY_ALIAS = "LatOPetHtheaCiar"
    }
}
