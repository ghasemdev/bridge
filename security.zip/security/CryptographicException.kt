package com.example.coffein.security

class CryptographicException(
  message: String,
  cause: Throwable? = null
) : Exception(message, cause)
