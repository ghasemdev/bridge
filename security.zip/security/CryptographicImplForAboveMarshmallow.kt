package com.example.coffein.security

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.annotation.RequiresApi
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.IvParameterSpec
import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.withContext

@RequiresApi(Build.VERSION_CODES.M)
internal class CryptographicImplForAboveMarshmallow : Cryptographic() {

  private val encryptionCipher by lazy {
    Cipher.getInstance(TRANSFORMATION).apply {
      init(Cipher.ENCRYPT_MODE, getKey())
    }
  }

  private fun getDecryptionCipher(iv: ByteArray): Cipher {
    val cipher = Cipher.getInstance(TRANSFORMATION)
    cipher.init(Cipher.DECRYPT_MODE, getKey(), IvParameterSpec(iv))
    return cipher
  }

  private fun getKey(): SecretKey {
    val existingKey = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
    return existingKey?.secretKey ?: createKey()
  }

  private fun createKey(): SecretKey {
    val keyGenerator = KeyGenerator.getInstance(ALGORITHM)
    keyGenerator.init(
      KeyGenParameterSpec.Builder(KEY_ALIAS, KEY_PURPOSES)
        .setBlockModes(BLOCK_MODE)
        .setEncryptionPaddings(PADDING)
        .setUserAuthenticationRequired(false) // Biometric authentication
        .setRandomizedEncryptionRequired(true)
        .build()
    )
    return keyGenerator.generateKey()
  }

  override fun encrypt(content: String): SecureData {
    val encryptedBytes = encryptionCipher.doFinal(content.encodeToByteArray())
    return SecureData(
      iv = encryptionCipher.iv.encodeBase64ToString(),
      plain = encryptedBytes.encodeBase64ToString()
    )
  }

  override fun decrypt(secureData: SecureData): String {
    val decryptionCipher = getDecryptionCipher(secureData.iv!!.decodeBase64ToBytes())
    val decryptedBytes = decryptionCipher.doFinal(secureData.plain.decodeBase64ToBytes())
    return decryptedBytes.decodeToString()
  }

  override suspend fun encrypt(
    bytes: ByteArray,
    outputStream: OutputStream,
    context: CoroutineContext
  ): ByteArray = withContext(context) {
    // Encrypt content
    val encryptedBytes = encryptionCipher.doFinal(bytes)

    // Write IV and encrypted bytes to OutputStream
    outputStream.buffered().use { bos ->
      bos.write(encryptionCipher.iv.size)
      bos.write(encryptionCipher.iv)
      bos.write(encryptedBytes)
    }
    encryptedBytes
  }

  override suspend fun decrypt(
    inputStream: InputStream,
    context: CoroutineContext
  ): ByteArray = withContext(context) {
    // Create a buffer for performance optimization
    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)

    inputStream.buffered().use { bis ->
      // Read IV to initialize decryption cipher
      val ivSize = bis.read()
      val iv = ByteArray(ivSize)
      bis.read(iv)

      val decryptionCipher = getDecryptionCipher(iv)
      var length = bis.read(buffer)

      val decryptedBytes = ByteArrayOutputStream().use {
        while (length != -1) {
          val tempBytes = decryptionCipher.update(buffer, 0, length)
          if (tempBytes != null && tempBytes.isNotEmpty()) {
            it.write(tempBytes)
          }

          length = bis.read(buffer)
        }
        it.write(decryptionCipher.doFinal())
        it.toByteArray()
      }
      decryptedBytes
    }
  }

  companion object {
    private const val KEY_PURPOSES =
      KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT

    private const val ALGORITHM = KeyProperties.KEY_ALGORITHM_AES // AES
    private const val BLOCK_MODE = KeyProperties.BLOCK_MODE_CBC // CBC
    private const val PADDING = KeyProperties.ENCRYPTION_PADDING_PKCS7 // PKCS7Padding
    private const val TRANSFORMATION = "$ALGORITHM/$BLOCK_MODE/$PADDING"
  }
}
