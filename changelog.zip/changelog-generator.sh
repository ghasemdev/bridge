#!/bin/bash
#
# Don't forget execute this commands first!!!
# >> chmod +x ./changelog-generator.sh

VERSIONS=$(git tag --sort=taggerdate | grep -E '^[0-9]+.[0-9]+.[0-9]+-usign$' | tail -2)

START_TAG=$(cut -d$'\n' -f1 <<< "$VERSIONS")
END_TAG=$(cut -d$'\n' -f2 <<< "$VERSIONS")

echo "Generate CHANGELOG.md for $START_TAG..$END_TAG"

MERGE_COMMITS=$(git log "$START_TAG".."$END_TAG" --merges --first-parent)

python3 commit-parser.py "$MERGE_COMMITS"
