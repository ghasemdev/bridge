#!/usr/bin/env python3

import sys
import re


pattern = r'\ncommit '


def main(args):
    commits = re.split(pattern, args[1][7::])
    for c in commits:
        print("------------------")
        print(c)


if __name__ == '__main__':
    main(sys.argv)
